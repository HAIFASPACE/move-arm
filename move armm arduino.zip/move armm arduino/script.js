bb.addEventListener('click',function(){
    var speech=true;
    window.SpeechRecognition=window.webkitSpeechRecognition;



    var recognitionA=new SpeechRecognition();
     recognitionA.interimResults=true;
    recognitionA.lang='ar-SA' ;

    recognitionA.addEventListener('result',e=>{
        const transcript=Array.from(e.results)
        .map(result=>result[0])
       .map(result=>result.transcript)

      convert_text.innerHTML=transcript;
   })

   if(speech==true){



recognitionA.start();

}



    })




    bb2.addEventListener('click',function(){
        var speech2=true;
        window.SpeechRecognition=window.webkitSpeechRecognition;



        var recognitionE=new SpeechRecognition();
         recognitionE.interimResults=true;
        recognitionE.lang='en' ;

        recognitionE.addEventListener('result',e=>{
            const transcriptE=Array.from(e.results)
            .map(result=>result[0])
           .map(result=>result.transcript)

          convert_text.innerHTML=transcriptE;
       })

       if(speech2==true){



    recognitionE.start();

    }












        })
